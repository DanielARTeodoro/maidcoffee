/*
* To change this license header, choose License Headers in Project Properties.
* To change this template file, choose Tools | Templates
* and open the template in the editor.
*/

/**
 * Sample Skeleton for 'Maid.fxml' Controller Class
 */

package br.com.maidcoffee.controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import br.com.maidcoffee.model.Cadastro;
import javafx.beans.property.SimpleStringProperty;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.stage.Stage;

/**
 * @author Daniel
 *
 */

public class MaidController {

	@FXML // ResourceBundle that was given to the FXMLLoader
	private ResourceBundle resources;

	@FXML // URL location of the FXML file that was given to the FXMLLoader
	private URL location;

	@FXML // fx:id="btnMaidBusccar"
	private Button btnMaidBusccar; // Value injected by FXMLLoader

	@FXML // fx:id="btnMaidDeletar"
	private Button btnMaidDeletar; // Value injected by FXMLLoader

	@FXML // fx:id="btnMaidCadastrar"
	private Button btnMaidCadastrar; // Value injected by FXMLLoader

	@FXML // fx:id="btnMaidEditar"
	private Button btnMaidEditar; // Value injected by FXMLLoader

	@FXML // fx:id="tvMaids"
	private TableView<?> tvMaids; // Value injected by FXMLLoader

	@FXML
	void handleSubmitButtonAction(ActionEvent event) {

		try {

			Parent root = FXMLLoader.load(getClass().getResource("../view/Cadastro.fxml"));
			Stage stage = new Stage();
			Scene scene = new Scene(root);
			stage.setScene(scene);
			stage.show();

		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	@FXML // This method is called by the FXMLLoader when initialization is complete
	void initialize() {
		assert btnMaidBusccar != null : "fx:id=\"btnMaidBusccar\" was not injected: check your FXML file 'Maid.fxml'.";
		assert btnMaidDeletar != null : "fx:id=\"btnMaidDeletar\" was not injected: check your FXML file 'Maid.fxml'.";
		assert btnMaidCadastrar != null : "fx:id=\"btnMaidCadastrar\" was not injected: check your FXML file 'Maid.fxml'.";
		assert btnMaidEditar != null : "fx:id=\"btnMaidEditar\" was not injected: check your FXML file 'Maid.fxml'.";
		assert tvMaids != null : "fx:id=\"tvMaids\" was not injected: check your FXML file 'Maid.fxml'.";

	}
}

/*
 * 
 * public class MaidController {
 * 
 * @FXML // ResourceBundle that was given to the FXMLLoader private
 * ResourceBundle resources;
 * 
 * @FXML // URL location of the FXML file that was given to the FXMLLoader
 * private URL location;
 * 
 * @FXML // fx:id="btnMaidBusccar" private Button btnMaidBusccar; // Value
 * injected by FXMLLoader
 * 
 * @FXML // fx:id="btnMaidDeletar" private Button btnMaidDeletar; // Value
 * injected by FXMLLoader
 * 
 * @FXML // fx:id="btnMaidCadastrar" private Button btnMaidCadastrar; // Value
 * injected by FXMLLoader
 * 
 * @FXML // fx:id="btnMaidEditar" private Button btnMaidEditar; // Value
 * injected by FXMLLoader
 * 
 * @FXML // fx:id="tvMaids" private TableView<Cadastro> tvMaids; // Value
 * injected by FXMLLoader
 * 
 * @FXML void handleSubmitButtonAction(ActionEvent event) {
 * 
 * try {
 * 
 * Parent root =
 * FXMLLoader.load(getClass().getResource("../view/Cadastro.fxml")); Stage stage
 * = new Stage(); Scene scene = new Scene(root); stage.setScene(scene);
 * stage.show();
 * 
 * } catch (IOException e) { e.printStackTrace(); }
 * 
 * }
 * 
 * @FXML // This method is called by the FXMLLoader when initialization is
 * complete void initialize() { /* TableColumn<Cadastro,String> colNomeMaid =
 * new TableColumn("NomeMaid"); colNomeMaid.setCellValueFactory(data -> new
 * SimpleStringProperty(data.getValue().getNomeMaid()));
 * 
 * TableColumn<Cadastro,String> colNome = new TableColumn("Nome");
 * colNome.setCellValueFactory(data -> new
 * SimpleStringProperty(data.getValue().getNome()));
 * 
 * TableColumn<Cadastro,String> colEmail = new TableColumn("Email");
 * colEmail.setCellValueFactory(data -> new
 * SimpleStringProperty(data.getValue().getEmail()));
 * 
 * tvMaids.getColumns().addAll(colNomeMaid, colNome, colEmail);
 * 
 * 
 * assert btnMaidBusccar != null :
 * "fx:id=\"btnMaidBusccar\" was not injected: check your FXML file 'Maid.fxml'."
 * ; assert btnMaidDeletar != null :
 * "fx:id=\"btnMaidDeletar\" was not injected: check your FXML file 'Maid.fxml'."
 * ; assert btnMaidCadastrar != null :
 * "fx:id=\"btnMaidCadastrar\" was not injected: check your FXML file 'Maid.fxml'."
 * ; assert btnMaidEditar != null :
 * "fx:id=\"btnMaidEditar\" was not injected: check your FXML file 'Maid.fxml'."
 * ; assert tvMaids != null :
 * "fx:id=\"tvMaids\" was not injected: check your FXML file 'Maid.fxml'.";
 * 
 * }
 * 
 * }
 */
