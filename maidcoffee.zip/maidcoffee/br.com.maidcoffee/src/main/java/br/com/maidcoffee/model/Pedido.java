/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package br.com.maidcoffee.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "tb_pedido")

public class Pedido {

	@Id
	@GeneratedValue
	@Column(name = "idPedido")

	private Integer id;

	/// Mesa

	@Column
	private String mesa;

	/// MAINS

	@Column
	private String quantidadeMains1;
	@Column
	private String quantidadeMains2;
	@Column
	private String quantidadeMains3;

	@Column
	private String pedidoMains1;
	@Column
	private String pedidoMains2;
	@Column
	private String pedidoMains3;

	/// DESSERTS

	@Column
	private String quantidadeDesserts1;
	@Column
	private String quantidadeDesserts2;
	@Column
	private String quantidadeDesserts3;

	@Column
	private String pedidoDesserts1;
	@Column
	private String pedidoDesserts2;
	@Column
	private String pedidoDesserts3;

	/// DRINKS

	@Column
	private String quantidadeDrinks1;
	@Column
	private String quantidadeDrinks2;
	@Column
	private String quantidadeDrinks3;

	@Column
	private String pedidoDrinks1;
	@Column
	private String pedidoDrinks2;
	@Column
	private String pedidoDrinks3;

	/**
	 * 
	 */
	public Pedido() {

	}

	/**
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}

	/**
	 * @return the mesa
	 */
	public String getMesa() {
		return mesa;
	}

	/**
	 * @param mesa the mesa to set
	 */
	public void setMesa(String mesa) {
		this.mesa = mesa;
	}

	/**
	 * @return the quantidadeMains1
	 */
	public String getQuantidadeMains1() {
		return quantidadeMains1;
	}

	/**
	 * @param quantidadeMains1 the quantidadeMains1 to set
	 */
	public void setQuantidadeMains1(String quantidadeMains1) {
		this.quantidadeMains1 = quantidadeMains1;
	}

	/**
	 * @return the quantidadeMains2
	 */
	public String getQuantidadeMains2() {
		return quantidadeMains2;
	}

	/**
	 * @param quantidadeMains2 the quantidadeMains2 to set
	 */
	public void setQuantidadeMains2(String quantidadeMains2) {
		this.quantidadeMains2 = quantidadeMains2;
	}

	/**
	 * @return the quantidadeMains3
	 */
	public String getQuantidadeMains3() {
		return quantidadeMains3;
	}

	/**
	 * @param quantidadeMains3 the quantidadeMains3 to set
	 */
	public void setQuantidadeMains3(String quantidadeMains3) {
		this.quantidadeMains3 = quantidadeMains3;
	}

	/**
	 * @return the pedidoMains1
	 */
	public String getPedidoMains1() {
		return pedidoMains1;
	}

	/**
	 * @param pedidoMains1 the pedidoMains1 to set
	 */
	public void setPedidoMains1(String pedidoMains1) {
		this.pedidoMains1 = pedidoMains1;
	}

	/**
	 * @return the pedidoMains2
	 */
	public String getPedidoMains2() {
		return pedidoMains2;
	}

	/**
	 * @param pedidoMains2 the pedidoMains2 to set
	 */
	public void setPedidoMains2(String pedidoMains2) {
		this.pedidoMains2 = pedidoMains2;
	}

	/**
	 * @return the pedidoMains3
	 */
	public String getPedidoMains3() {
		return pedidoMains3;
	}

	/**
	 * @param pedidoMains3 the pedidoMains3 to set
	 */
	public void setPedidoMains3(String pedidoMains3) {
		this.pedidoMains3 = pedidoMains3;
	}

	/**
	 * @return the quantidadeDesserts1
	 */
	public String getQuantidadeDesserts1() {
		return quantidadeDesserts1;
	}

	/**
	 * @param quantidadeDesserts1 the quantidadeDesserts1 to set
	 */
	public void setQuantidadeDesserts1(String quantidadeDesserts1) {
		this.quantidadeDesserts1 = quantidadeDesserts1;
	}

	/**
	 * @return the quantidadeDesserts2
	 */
	public String getQuantidadeDesserts2() {
		return quantidadeDesserts2;
	}

	/**
	 * @param quantidadeDesserts2 the quantidadeDesserts2 to set
	 */
	public void setQuantidadeDesserts2(String quantidadeDesserts2) {
		this.quantidadeDesserts2 = quantidadeDesserts2;
	}

	/**
	 * @return the quantidadeDesserts3
	 */
	public String getQuantidadeDesserts3() {
		return quantidadeDesserts3;
	}

	/**
	 * @param quantidadeDesserts3 the quantidadeDesserts3 to set
	 */
	public void setQuantidadeDesserts3(String quantidadeDesserts3) {
		this.quantidadeDesserts3 = quantidadeDesserts3;
	}

	/**
	 * @return the pedidoDesserts1
	 */
	public String getPedidoDesserts1() {
		return pedidoDesserts1;
	}

	/**
	 * @param pedidoDesserts1 the pedidoDesserts1 to set
	 */
	public void setPedidoDesserts1(String pedidoDesserts1) {
		this.pedidoDesserts1 = pedidoDesserts1;
	}

	/**
	 * @return the pedidoDesserts2
	 */
	public String getPedidoDesserts2() {
		return pedidoDesserts2;
	}

	/**
	 * @param pedidoDesserts2 the pedidoDesserts2 to set
	 */
	public void setPedidoDesserts2(String pedidoDesserts2) {
		this.pedidoDesserts2 = pedidoDesserts2;
	}

	/**
	 * @return the pedidoDesserts3
	 */
	public String getPedidoDesserts3() {
		return pedidoDesserts3;
	}

	/**
	 * @param pedidoDesserts3 the pedidoDesserts3 to set
	 */
	public void setPedidoDesserts3(String pedidoDesserts3) {
		this.pedidoDesserts3 = pedidoDesserts3;
	}

	/**
	 * @return the quantidadeDrinks1
	 */
	public String getQuantidadeDrinks1() {
		return quantidadeDrinks1;
	}

	/**
	 * @param quantidadeDrinks1 the quantidadeDrinks1 to set
	 */
	public void setQuantidadeDrinks1(String quantidadeDrinks1) {
		this.quantidadeDrinks1 = quantidadeDrinks1;
	}

	/**
	 * @return the quantidadeDrinks2
	 */
	public String getQuantidadeDrinks2() {
		return quantidadeDrinks2;
	}

	/**
	 * @param quantidadeDrinks2 the quantidadeDrinks2 to set
	 */
	public void setQuantidadeDrinks2(String quantidadeDrinks2) {
		this.quantidadeDrinks2 = quantidadeDrinks2;
	}

	/**
	 * @return the quantidadeDrinks3
	 */
	public String getQuantidadeDrinks3() {
		return quantidadeDrinks3;
	}

	/**
	 * @param quantidadeDrinks3 the quantidadeDrinks3 to set
	 */
	public void setQuantidadeDrinks3(String quantidadeDrinks3) {
		this.quantidadeDrinks3 = quantidadeDrinks3;
	}

	/**
	 * @return the pedidoDrinks1
	 */
	public String getPedidoDrinks1() {
		return pedidoDrinks1;
	}

	/**
	 * @param pedidoDrinks1 the pedidoDrinks1 to set
	 */
	public void setPedidoDrinks1(String pedidoDrinks1) {
		this.pedidoDrinks1 = pedidoDrinks1;
	}

	/**
	 * @return the pedidoDrinks2
	 */
	public String getPedidoDrinks2() {
		return pedidoDrinks2;
	}

	/**
	 * @param pedidoDrinks2 the pedidoDrinks2 to set
	 */
	public void setPedidoDrinks2(String pedidoDrinks2) {
		this.pedidoDrinks2 = pedidoDrinks2;
	}

	/**
	 * @return the pedidoDrinks3
	 */
	public String getPedidoDrinks3() {
		return pedidoDrinks3;
	}

	/**
	 * @param pedidoDrinks3 the pedidoDrinks3 to set
	 */
	public void setPedidoDrinks3(String pedidoDrinks3) {
		this.pedidoDrinks3 = pedidoDrinks3;
	}

}
