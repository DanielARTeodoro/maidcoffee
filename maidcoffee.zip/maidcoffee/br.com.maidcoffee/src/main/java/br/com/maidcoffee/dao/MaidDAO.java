/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.maidcoffee.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

// import br.com.maidcoffee.model.Cadastro;

import br.com.maidcoffee.model.Maid;

/**
 * @author Daniel
 *
 */
public class MaidDAO {

	static final Logger logger = LogManager.getLogger(MaidDAO.class.getName());
	final EntityManagerFactory emf = Persistence.createEntityManagerFactory("maidcoffee");
	protected EntityManager em = null;

	public MaidDAO() {
		super();
		if (em == null) {
			em = emf.createEntityManager();
		}

	}
	
	
	public Maid getById(final int id) {
		return em.find(Maid.class, id);
	}

	

	public List<Maid> getAll() {
		em.getTransaction().begin();
		@SuppressWarnings("unchecked")
		List<Maid> maid = em.createQuery("FROM " + Maid.class.getName()).getResultList();
		return maid;
		
	}
	

	public void inserir(Maid m) {
		logger.info("Adicionando PessoaDAO ao BD");
		try {
			em.getTransaction().begin();
			em.persist(m);
			em.getTransaction().commit();
		} catch (Exception e) {
			// TODO: handle exception logger.error("Erro ao inserir Pessoa" +
			// e.getMessage());
			em.getTransaction().rollback();
		} finally {
			em.clear();
			em.close();
		}

	}

	public void remover(Maid m) {

		logger.info("Removeido o Pessoa do BD");
		try {
			em.getTransaction().begin();
			em.remove(m);
			em.getTransaction().commit();
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Erro ao remover o Pessoa" + e.getMessage());
			em.getTransaction().rollback();
		} finally {
			em.clear();
			em.close();

		}

	}

	public void alterar(Maid m) {

		logger.info("alterado o Pessoa do BD");
		try {
			em.getTransaction().begin();
			em.merge(m);
			em.getTransaction().commit();
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Erro ao alterar o Pessoa" + e.getMessage());
			em.getTransaction().rollback();
		} finally {
			em.clear();
			em.close();

		}

	}

	/*
	
	public List<Cadastro> consultarTodos() {

		return em.createQuery("FROM " + Cadastro.class.getName()).getResultList();
	}

*/

	/// public void consultarNome() {}

}
