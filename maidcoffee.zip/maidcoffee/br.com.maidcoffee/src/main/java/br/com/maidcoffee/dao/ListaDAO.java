/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.maidcoffee.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/// import br.com.maidcoffee.model.Cadastro;

import br.com.maidcoffee.model.Lista;

/**
 * @author Daniel
 *
 */
public class ListaDAO {

	static final Logger logger = LogManager.getLogger(ListaDAO.class.getName());
	final EntityManagerFactory emf = Persistence.createEntityManagerFactory("maidcoffee");
	protected EntityManager em = null;

	public ListaDAO() {
		super();
		if (em == null) {
			em = emf.createEntityManager();
		}

	}

	public Lista getById(final int id) {
		return em.find(Lista.class, id);
	}

	public List<Lista> getAll() {
		em.getTransaction().begin();
		@SuppressWarnings("unchecked")
		List<Lista> lista = em.createQuery("FROM " + Lista.class.getName()).getResultList();
		return lista;
	}

	public void inserir(Lista l) {
		logger.info("Adicionando Lista ao BD");
		try {
			em.getTransaction().begin();
			em.persist(l);
			em.getTransaction().commit();
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Erro ao inserir Lista" + e.getMessage());
			em.getTransaction().rollback();
		} finally {
			em.clear();
			em.close();
		}

	}

	public void alterar(Lista l) {

		logger.info("alterado o Lista do BD");
		try {
			em.getTransaction().begin();
			em.merge(l);
			em.getTransaction().commit();
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Erro ao alterar o Lista" + e.getMessage());
			em.getTransaction().rollback();
		} finally {
			em.clear();
			em.close();

		}

	}

	public void remover(Lista l) {

		logger.info("Removeido o Lista do BD");
		try {
			em.getTransaction().begin();
			em.remove(l);
			em.getTransaction().commit();
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Erro ao remover o Lista" + e.getMessage());
			em.getTransaction().rollback();
		} finally {
			em.clear();
			em.close();

		}

	}
/*
	public List<Cadastro> consultarTodos() {

		return em.createQuery("FROM " + Cadastro.class.getName()).getResultList();
	}
*/
	/// public void consultarNome() {}

}
