/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.maidcoffee.dao;


import java.sql.Connection;
import java.util.List;

/*
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
*/
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;


/// import com.mysql.cj.x.protobuf.MysqlxNotice.Warning.Level;


import br.com.maidcoffee.model.Pedido;

/**
 * @author Daniel
 *
 */
public class PedidoDAO {
	
	

    private Connection connection;

    public Connection getConnection() {
        return connection;
    }

    public void setConnection(Connection connection) {
        this.connection = connection;
    }

	static final Logger logger = LogManager.getLogger(PedidoDAO.class.getName());
	final EntityManagerFactory emf = Persistence.createEntityManagerFactory("maidcoffee");
	protected EntityManager em = null;

	public PedidoDAO() {
		super();
		if (em == null) {
			em = emf.createEntityManager();
		}

	}

	
	public Pedido getById(final int id) {
		return em.find(Pedido.class, id);
	}
	
	public List<Pedido> getAll() {
		em.getTransaction().begin();
		@SuppressWarnings("unchecked")
		List<Pedido> pedido = em.createQuery("FROM " + Pedido.class.getName()).getResultList();
		return pedido;
	}
	
	public void inserir(Pedido p) {
		logger.info("Adicionando Pedido ao BD");
		try {
			em.getTransaction().begin();
			em.persist(p);
			em.getTransaction().commit();
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Erro ao inserir Pedido" + e.getMessage());
			em.getTransaction().rollback();
		} finally {
			em.clear();
			em.close();
		}

	}
	
	public void remover(Pedido p) {

		logger.info("Removeido o Pedido do BD");
		try {
			em.getTransaction().begin();
			em.remove(p);
			em.getTransaction().commit();
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Erro ao remover o Pedido" + e.getMessage());
			em.getTransaction().rollback();
		} finally {
			em.clear();
			em.close();

		}
		
	}
	
	/*
	public List<Pedido> listar() {
        String sql = "SELECT * FROM pedido";
        List<Pedido> retorno = new ArrayList<>();
        try {
            PreparedStatement stmt = connection.prepareStatement(sql);
            ResultSet resultado = stmt.executeQuery();
            while (resultado.next()) {
                Pedido pedido = new Pedido();
                pedido.setMesa(resultado.getString("mesa"));
                pedido.setPedidoMains1(resultado.getString("pedidoMains1"));
                pedido.setPedidoMains2(resultado.getString("pedidoMains2"));
                pedido.setPedidoMains3(resultado.getString("pedidoMains3"));
                pedido.setQuantidadeMains1(resultado.getString("quantidadeMains1"));
                pedido.setQuantidadeMains2(resultado.getString("quantidadeMains2"));
                pedido.setQuantidadeMains3(resultado.getString("quantidadeMains3"));
                pedido.setPedidoDesserts1(resultado.getString("pedidoDesserts1"));
                pedido.setPedidoDesserts2(resultado.getString("pedidoDesserts2"));
                pedido.setPedidoDesserts3(resultado.getString("pedidoDesserts3"));
                pedido.setQuantidadeDesserts1(resultado.getString("quantidadeDesserts1"));
                pedido.setQuantidadeDesserts2(resultado.getString("quantidadeDesserts2"));
                pedido.setQuantidadeDesserts3(resultado.getString("quantidadeDesserts3"));
                pedido.setPedidoDrinks1(resultado.getString("pedidoDrinks1"));
                pedido.setPedidoDrinks2(resultado.getString("pedidoDrinks2"));
                pedido.setPedidoDrinks3(resultado.getString("pedidoDrinks3"));
                pedido.setQuantidadeDrinks1(resultado.getString("quantidadeDrinks1"));
                pedido.setQuantidadeDrinks2(resultado.getString("quantidadeDrinks2"));
                pedido.setQuantidadeDrinks3(resultado.getString("quantidadeDrinks3"));
                
                
                
                
                
            }
        } catch (SQLException ex) {
            Logger.getLogger(PedidoDAO.class.getName()).log(Level.superVERE, null, ex);
        }
        return retorno;
    }
	*/
	
}
