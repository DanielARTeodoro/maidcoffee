/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.maidcoffee.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "tb_maid")

/**
 *
 * @author Daniel
 */
public class Maid {

	@Id
	@GeneratedValue
	@Column(name = "idMaid")

	private Integer id;

	@Column
	private String maidNome;
	@Column
	private String maidNomeMaid;
	@Column
	private String maidEmail;

	/**
	 * 
	 */
	public Maid() {

	}

	/**
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}

	/**
	 * @return the maidNome
	 */
	public String getMaidNome() {
		return maidNome;
	}

	/**
	 * @param maidNome the maidNome to set
	 */
	public void setMaidNome(String maidNome) {
		this.maidNome = maidNome;
	}

	/**
	 * @return the maidNomeMaid
	 */
	public String getMaidNomeMaid() {
		return maidNomeMaid;
	}

	/**
	 * @param maidNomeMaid the maidNomeMaid to set
	 */
	public void setMaidNomeMaid(String maidNomeMaid) {
		this.maidNomeMaid = maidNomeMaid;
	}

	/**
	 * @return the maidEmail
	 */
	public String getMaidEmail() {
		return maidEmail;
	}

	/**
	 * @param maidEmail the maidEmail to set
	 */
	public void setMaidEmail(String maidEmail) {
		this.maidEmail = maidEmail;
	}

}
