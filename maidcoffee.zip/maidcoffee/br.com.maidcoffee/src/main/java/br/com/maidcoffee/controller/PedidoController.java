/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Sample Skeleton for 'PedidoNew.fxml' Controller Class
 */

package br.com.maidcoffee.controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import br.com.maidcoffee.dao.PedidoDAO;
import br.com.maidcoffee.model.Pedido;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;



/**
 * @author Daniel
 *
 */

public class PedidoController {

	@FXML // ResourceBundle that was given to the FXMLLoader
	private ResourceBundle resources;

	@FXML // URL location of the FXML file that was given to the FXMLLoader
	private URL location;

	@FXML // fx:id="btnPedir"
	private Button btnPedir; // Value injected by FXMLLoader

	@FXML // fx:id="btnLista"
	private Button btnLista; // Value injected by FXMLLoader

	@FXML // fx:id="txtPedidoMains1"
	private TextField txtPedidoMains1; // Value injected by FXMLLoader

	@FXML // fx:id="txtQuantidadeMains1"
	private TextField txtQuantidadeMains1; // Value injected by FXMLLoader

	@FXML // fx:id="txtPedidoDesserts1"
	private TextField txtPedidoDesserts1; // Value injected by FXMLLoader

	@FXML // fx:id="txtQuantidadeDesserts1"
	private TextField txtQuantidadeDesserts1; // Value injected by FXMLLoader

	@FXML // fx:id="txtPedidoDrinks1"
	private TextField txtPedidoDrinks1; // Value injected by FXMLLoader

	@FXML // fx:id="txtQuantidadeDrinks1"
	private TextField txtQuantidadeDrinks1; // Value injected by FXMLLoader

	@FXML // fx:id="txtMesa"
	private TextField txtMesa; // Value injected by FXMLLoader

	@FXML // fx:id="txtPedidoMains2"
	private TextField txtPedidoMains2; // Value injected by FXMLLoader

	@FXML // fx:id="txtQuantidadeMains2"
	private TextField txtQuantidadeMains2; // Value injected by FXMLLoader

	@FXML // fx:id="txtPedidoMains3"
	private TextField txtPedidoMains3; // Value injected by FXMLLoader

	@FXML // fx:id="txtQuantidadeMains3"
	private TextField txtQuantidadeMains3; // Value injected by FXMLLoader

	@FXML // fx:id="txtPedidoDesserts2"
	private TextField txtPedidoDesserts2; // Value injected by FXMLLoader

	@FXML // fx:id="txtQuantidadeDesserts2"
	private TextField txtQuantidadeDesserts2; // Value injected by FXMLLoader

	@FXML // fx:id="txtPedidoDesserts3"
	private TextField txtPedidoDesserts3; // Value injected by FXMLLoader

	@FXML // fx:id="txtQuantidadeDesserts3"
	private TextField txtQuantidadeDesserts3; // Value injected by FXMLLoader

	@FXML // fx:id="txtPedidoDrinks2"
	private TextField txtPedidoDrinks2; // Value injected by FXMLLoader

	@FXML // fx:id="txtQuantidadeDrinks2"
	private TextField txtQuantidadeDrinks2; // Value injected by FXMLLoader

	@FXML // fx:id="txtPedidoDrinks3"
	private TextField txtPedidoDrinks3; // Value injected by FXMLLoader

	@FXML // fx:id="txtQuantidadeDrinks3"
	private TextField txtQuantidadeDrinks3; // Value injected by FXMLLoader

	@FXML
	void handleButtonConfirmar(ActionEvent event) {
		

		if (btnPedir.isDisable()) {

			txtMesa.setDisable(false);
			txtPedidoMains1.setDisable(false);
			txtPedidoMains2.setDisable(false);
			txtPedidoMains3.setDisable(false);
			txtQuantidadeMains1.setDisable(false);
			txtQuantidadeMains2.setDisable(false);
			txtQuantidadeMains3.setDisable(false);
			txtPedidoDesserts1.setDisable(false);
			txtPedidoDesserts2.setDisable(false);
			txtPedidoDesserts3.setDisable(false);
			txtQuantidadeDesserts1.setDisable(false);
			txtQuantidadeDesserts2.setDisable(false);
			txtQuantidadeDesserts3.setDisable(false);
			txtPedidoDrinks1.setDisable(false);
			txtPedidoDrinks2.setDisable(false);
			txtPedidoDrinks3.setDisable(false);
			txtQuantidadeDrinks1.setDisable(false);
			txtQuantidadeDrinks2.setDisable(false);
			txtQuantidadeDrinks3.setDisable(false);
			

		}

		if (txtMesa.getText().equals("") && txtPedidoMains1.getText().equals("") && txtQuantidadeMains1.getText().equals("")
				&& txtPedidoDesserts1.getText().equals("") && txtQuantidadeDesserts1.getText().equals("") && txtPedidoDrinks1.getText().equals("") && txtQuantidadeDrinks1.getText().equals("")
				&& txtPedidoMains2.getText().equals("") && txtQuantidadeMains2.getText().equals("")
				&& txtPedidoDesserts2.getText().equals("") && txtQuantidadeDesserts2.getText().equals("") && txtPedidoDrinks2.getText().equals("") && txtQuantidadeDrinks2.getText().equals("")
				&& txtPedidoMains3.getText().equals("") && txtQuantidadeMains3.getText().equals("")
				&& txtPedidoDesserts3.getText().equals("") && txtQuantidadeDesserts3.getText().equals("") && txtPedidoDrinks3.getText().equals("") && txtQuantidadeDrinks3.getText().equals("")
				) {

			try {

				Parent root = FXMLLoader.load(getClass().getResource("../view/Erro.fxml"));
				Stage stage = (Stage) btnPedir.getScene().getWindow();
				Scene scene = new Scene(root);
				stage.setScene(scene);
				stage.show();

			} catch (IOException e) {
				e.printStackTrace();
			}

		} else {

			Pedido p = new Pedido();
			p.setMesa(txtMesa.getText());
			p.setPedidoMains1(txtPedidoMains1.getText());
			p.setPedidoMains2(txtPedidoMains2.getText());
			p.setPedidoMains3(txtPedidoMains3.getText());
			p.setPedidoDesserts1(txtPedidoDesserts1.getText());
			p.setPedidoDesserts2(txtPedidoDesserts2.getText());
			p.setPedidoDesserts3(txtPedidoDesserts3.getText());
			p.setPedidoDrinks1(txtPedidoDrinks1.getText());
			p.setPedidoDrinks2(txtPedidoDrinks2.getText());
			p.setPedidoDrinks3(txtPedidoDrinks3.getText());
			p.setQuantidadeMains1(txtQuantidadeMains1.getText());
			p.setQuantidadeMains2(txtQuantidadeMains2.getText());
			p.setQuantidadeMains3(txtQuantidadeMains3.getText());
			p.setQuantidadeDesserts1(txtQuantidadeDesserts1.getText());
			p.setQuantidadeDesserts2(txtQuantidadeDesserts2.getText());
			p.setQuantidadeDesserts3(txtQuantidadeDesserts3.getText());
			p.setQuantidadeDrinks1(txtQuantidadeDrinks1.getText());
			p.setQuantidadeDrinks2(txtQuantidadeDrinks2.getText());
			p.setQuantidadeDrinks3(txtQuantidadeDrinks3.getText());
			

			PedidoDAO pedidoDAO  = new PedidoDAO();
			pedidoDAO.inserir(p);
			
			txtMesa.setDisable(true);
			txtPedidoMains1.setDisable(true);
			txtPedidoMains2.setDisable(true);
			txtPedidoMains3.setDisable(true);
			txtQuantidadeMains1.setDisable(true);
			txtQuantidadeMains2.setDisable(true);
			txtQuantidadeMains3.setDisable(true);
			txtPedidoDesserts1.setDisable(true);
			txtPedidoDesserts2.setDisable(true);
			txtPedidoDesserts3.setDisable(true);
			txtQuantidadeDesserts1.setDisable(true);
			txtQuantidadeDesserts2.setDisable(true);
			txtQuantidadeDesserts3.setDisable(true);
			txtPedidoDrinks1.setDisable(true);
			txtPedidoDrinks2.setDisable(true);
			txtPedidoDrinks3.setDisable(true);
			txtQuantidadeDrinks1.setDisable(true);
			txtQuantidadeDrinks2.setDisable(true);
			txtQuantidadeDrinks3.setDisable(true);

			try {

				Parent root = FXMLLoader.load(getClass().getResource("../view/Ok.fxml"));
				Stage stage = (Stage) btnPedir.getScene().getWindow();
				Scene scene = new Scene(root);
				stage.setScene(scene);
				stage.show();

			} catch (IOException e) {
				e.printStackTrace();
			}

		}
		
	}
					

	@FXML
	void handleSubmitButtonAction(ActionEvent event) {

		try {

			Parent root = FXMLLoader.load(getClass().getResource("../view/Lista.fxml"));
			Stage stage = new Stage();
			Scene scene = new Scene(root);
			stage.setScene(scene);
			stage.show();

		} catch (IOException e) {
			e.printStackTrace();

		}
	}

	@FXML // This method is called by the FXMLLoader when initialization is complete
	void initialize() {
		assert btnPedir != null : "fx:id=\"btnPedir\" was not injected: check your FXML file 'PedidoNew.fxml'.";
		assert btnLista != null : "fx:id=\"btnLista\" was not injected: check your FXML file 'PedidoNew.fxml'.";
		assert txtPedidoMains1 != null : "fx:id=\"txtPedidoMains1\" was not injected: check your FXML file 'PedidoNew.fxml'.";
		assert txtQuantidadeMains1 != null : "fx:id=\"txtQuantidadeMains1\" was not injected: check your FXML file 'PedidoNew.fxml'.";
		assert txtPedidoDesserts1 != null : "fx:id=\"txtPedidoDesserts1\" was not injected: check your FXML file 'PedidoNew.fxml'.";
		assert txtQuantidadeDesserts1 != null : "fx:id=\"txtQuantidadeDesserts1\" was not injected: check your FXML file 'PedidoNew.fxml'.";
		assert txtPedidoDrinks1 != null : "fx:id=\"txtPedidoDrinks1\" was not injected: check your FXML file 'PedidoNew.fxml'.";
		assert txtQuantidadeDrinks1 != null : "fx:id=\"txtQuantidadeDrinks1\" was not injected: check your FXML file 'PedidoNew.fxml'.";
		assert txtMesa != null : "fx:id=\"txtMesa\" was not injected: check your FXML file 'PedidoNew.fxml'.";
		assert txtPedidoMains2 != null : "fx:id=\"txtPedidoMains2\" was not injected: check your FXML file 'PedidoNew.fxml'.";
		assert txtQuantidadeMains2 != null : "fx:id=\"txtQuantidadeMains2\" was not injected: check your FXML file 'PedidoNew.fxml'.";
		assert txtPedidoMains3 != null : "fx:id=\"txtPedidoMains3\" was not injected: check your FXML file 'PedidoNew.fxml'.";
		assert txtQuantidadeMains3 != null : "fx:id=\"txtQuantidadeMains3\" was not injected: check your FXML file 'PedidoNew.fxml'.";
		assert txtPedidoDesserts2 != null : "fx:id=\"txtPedidoDesserts2\" was not injected: check your FXML file 'PedidoNew.fxml'.";
		assert txtQuantidadeDesserts2 != null : "fx:id=\"txtQuantidadeDesserts2\" was not injected: check your FXML file 'PedidoNew.fxml'.";
		assert txtPedidoDesserts3 != null : "fx:id=\"txtPedidoDesserts3\" was not injected: check your FXML file 'PedidoNew.fxml'.";
		assert txtQuantidadeDesserts3 != null : "fx:id=\"txtQuantidadeDesserts3\" was not injected: check your FXML file 'PedidoNew.fxml'.";
		assert txtPedidoDrinks2 != null : "fx:id=\"txtPedidoDrinks2\" was not injected: check your FXML file 'PedidoNew.fxml'.";
		assert txtQuantidadeDrinks2 != null : "fx:id=\"txtQuantidadeDrinks2\" was not injected: check your FXML file 'PedidoNew.fxml'.";
		assert txtPedidoDrinks3 != null : "fx:id=\"txtPedidoDrinks3\" was not injected: check your FXML file 'PedidoNew.fxml'.";
		assert txtQuantidadeDrinks3 != null : "fx:id=\"txtQuantidadeDrinks3\" was not injected: check your FXML file 'PedidoNew.fxml'.";

	}
}

/*
 * /** Sample Skeleton for 'PedidoNew.fxml' Controller Class
 */
/*
 * package br.com.maidcoffee.controller;
 * 
 * import java.io.IOException; import java.net.URL; import
 * java.util.ResourceBundle;
 * 
 * import br.com.maidcoffee.model.Pedido; import javafx.event.ActionEvent;
 * import javafx.fxml.FXML; import javafx.fxml.FXMLLoader; import
 * javafx.scene.Parent; import javafx.scene.Scene; import
 * javafx.scene.control.Button; import javafx.scene.control.TextField; import
 * javafx.stage.Stage;
 * 
 * /**
 * 
 * @author Daniel
 *
 */
/*
 * public class PedidoController {
 * 
 * @FXML // ResourceBundle that was given to the FXMLLoader private
 * ResourceBundle resources;
 * 
 * @FXML // URL location of the FXML file that was given to the FXMLLoader
 * private URL location;
 * 
 * @FXML // fx:id="btnPedir" private Button btnPedir; // Value injected by
 * FXMLLoader
 * 
 * @FXML // fx:id="btnLista" private Button btnLista; // Value injected by
 * FXMLLoader
 * 
 * @FXML // fx:id="txtPedidoMains1" private TextField txtPedidoMains1; // Value
 * injected by FXMLLoader
 * 
 * @FXML // fx:id="txtQuantidadeMains1" private TextField txtQuantidadeMains1;
 * // Value injected by FXMLLoader
 * 
 * @FXML // fx:id="txtPedidoDesserts1" private TextField txtPedidoDesserts1; //
 * Value injected by FXMLLoader
 * 
 * @FXML // fx:id="txtQuantidadeDesserts1" private TextField
 * txtQuantidadeDesserts1; // Value injected by FXMLLoader
 * 
 * @FXML // fx:id="txtPedidoDrinks1" private TextField txtPedidoDrinks1; //
 * Value injected by FXMLLoader
 * 
 * @FXML // fx:id="txtQuantidadeDrinks1" private TextField txtQuantidadeDrinks1;
 * // Value injected by FXMLLoader
 * 
 * @FXML // fx:id="txtMesa" private TextField txtMesa; // Value injected by
 * FXMLLoader
 * 
 * @FXML // fx:id="txtPedidoMains2" private TextField txtPedidoMains2; // Value
 * injected by FXMLLoader
 * 
 * @FXML // fx:id="txtQuantidadeMains2" private TextField txtQuantidadeMains2;
 * // Value injected by FXMLLoader
 * 
 * @FXML // fx:id="txtPedidoMains3" private TextField txtPedidoMains3; // Value
 * injected by FXMLLoader
 * 
 * @FXML // fx:id="txtQuantidadeMains3" private TextField txtQuantidadeMains3;
 * // Value injected by FXMLLoader
 * 
 * @FXML // fx:id="txtPedidoDesserts2" private TextField txtPedidoDesserts2; //
 * Value injected by FXMLLoader
 * 
 * @FXML // fx:id="txtQuantidadeDesserts2" private TextField
 * txtQuantidadeDesserts2; // Value injected by FXMLLoader
 * 
 * @FXML // fx:id="txtPedidoDesserts3" private TextField txtPedidoDesserts3; //
 * Value injected by FXMLLoader
 * 
 * @FXML // fx:id="txtQuantidadeDesserts3" private TextField
 * txtQuantidadeDesserts3; // Value injected by FXMLLoader
 * 
 * @FXML // fx:id="txtPedidoDrinks2" private TextField txtPedidoDrinks2; //
 * Value injected by FXMLLoader
 * 
 * @FXML // fx:id="txtQuantidadeDrinks2" private TextField txtQuantidadeDrinks2;
 * // Value injected by FXMLLoader
 * 
 * @FXML // fx:id="txtPedidoDrinks3" private TextField txtPedidoDrinks3; //
 * Value injected by FXMLLoader
 * 
 * @FXML // fx:id="txtQuantidadeDrinks3" private TextField txtQuantidadeDrinks3;
 * // Value injected by FXMLLoader
 * 
 * @FXML void handleSubmitButtonAction(ActionEvent event) {
 * 
 * try {
 * 
 * Parent root = FXMLLoader.load(getClass().getResource("../view/Lista.fxml"));
 * Stage stage = new Stage(); Scene scene = new Scene(root);
 * stage.setScene(scene); stage.show();
 * 
 * } catch (IOException e) { e.printStackTrace(); }
 * 
 * }
 * 
 * @FXML // This method is called by the FXMLLoader when initialization is
 * complete void initialize() { assert btnPedir != null :
 * "fx:id=\"btnPedir\" was not injected: check your FXML file 'PedidoNew.fxml'."
 * ; assert btnLista != null :
 * "fx:id=\"btnLista\" was not injected: check your FXML file 'PedidoNew.fxml'."
 * ; assert txtPedidoMains1 != null :
 * "fx:id=\"txtPedidoMains1\" was not injected: check your FXML file 'PedidoNew.fxml'."
 * ; assert txtQuantidadeMains1 != null :
 * "fx:id=\"txtQuantidadeMains1\" was not injected: check your FXML file 'PedidoNew.fxml'."
 * ; assert txtPedidoDesserts1 != null :
 * "fx:id=\"txtPedidoDesserts1\" was not injected: check your FXML file 'PedidoNew.fxml'."
 * ; assert txtQuantidadeDesserts1 != null :
 * "fx:id=\"txtQuantidadeDesserts1\" was not injected: check your FXML file 'PedidoNew.fxml'."
 * ; assert txtPedidoDrinks1 != null :
 * "fx:id=\"txtPedidoDrinks1\" was not injected: check your FXML file 'PedidoNew.fxml'."
 * ; assert txtQuantidadeDrinks1 != null :
 * "fx:id=\"txtQuantidadeDrinks1\" was not injected: check your FXML file 'PedidoNew.fxml'."
 * ; assert txtMesa != null :
 * "fx:id=\"txtMesa\" was not injected: check your FXML file 'PedidoNew.fxml'.";
 * assert txtPedidoMains2 != null :
 * "fx:id=\"txtPedidoMains2\" was not injected: check your FXML file 'PedidoNew.fxml'."
 * ; assert txtQuantidadeMains2 != null :
 * "fx:id=\"txtQuantidadeMains2\" was not injected: check your FXML file 'PedidoNew.fxml'."
 * ; assert txtPedidoMains3 != null :
 * "fx:id=\"txtPedidoMains3\" was not injected: check your FXML file 'PedidoNew.fxml'."
 * ; assert txtQuantidadeMains3 != null :
 * "fx:id=\"txtQuantidadeMains3\" was not injected: check your FXML file 'PedidoNew.fxml'."
 * ; assert txtPedidoDesserts2 != null :
 * "fx:id=\"txtPedidoDesserts2\" was not injected: check your FXML file 'PedidoNew.fxml'."
 * ; assert txtQuantidadeDesserts2 != null :
 * "fx:id=\"txtQuantidadeDesserts2\" was not injected: check your FXML file 'PedidoNew.fxml'."
 * ; assert txtPedidoDesserts3 != null :
 * "fx:id=\"txtPedidoDesserts3\" was not injected: check your FXML file 'PedidoNew.fxml'."
 * ; assert txtQuantidadeDesserts3 != null :
 * "fx:id=\"txtQuantidadeDesserts3\" was not injected: check your FXML file 'PedidoNew.fxml'."
 * ; assert txtPedidoDrinks2 != null :
 * "fx:id=\"txtPedidoDrinks2\" was not injected: check your FXML file 'PedidoNew.fxml'."
 * ; assert txtQuantidadeDrinks2 != null :
 * "fx:id=\"txtQuantidadeDrinks2\" was not injected: check your FXML file 'PedidoNew.fxml'."
 * ; assert txtPedidoDrinks3 != null :
 * "fx:id=\"txtPedidoDrinks3\" was not injected: check your FXML file 'PedidoNew.fxml'."
 * ; assert txtQuantidadeDrinks3 != null :
 * "fx:id=\"txtQuantidadeDrinks3\" was not injected: check your FXML file 'PedidoNew.fxml'."
 * ;
 * 
 * }
 * 
 * /* //Atributos para manipula��o de Banco de Dados private final Database
 * database = DatabaseFactory.getDatabase("postgresql"); private final
 * Connection connection = database.conectar(); private final ClienteDAO
 * clienteDAO = new ClienteDAO();
 */

/*
 * 
 * private Stage dialogStage; private boolean buttonConfirmarClicked = false;
 * private Pedido pedido;
 * 
 * /**
 * 
 * @return the dialogStage
 */

/*
 * public Stage getDialogStage() { return dialogStage; }
 * 
 * /**
 * 
 * @param dialogStage the dialogStage to set
 * 
 * public void setDialogStage(Stage dialogStage) { this.dialogStage =
 * dialogStage; }
 * 
 * /**
 * 
 * @return the buttonConfirmarClicked
 * 
 * public boolean isButtonConfirmarClicked() { return buttonConfirmarClicked; }
 * 
 * /**
 * 
 * @param buttonConfirmarClicked the buttonConfirmarClicked to set
 * 
 * public void setButtonConfirmarClicked(boolean buttonConfirmarClicked) {
 * this.buttonConfirmarClicked = buttonConfirmarClicked; }
 * 
 * /**
 * 
 * @return the pedido
 * 
 * public Pedido getPedido() { return pedido; }
 * 
 * /**
 * 
 * @param pedido the pedido to set
 *
 * public void setPedido(Pedido pedido) { this.pedido = pedido;
 * this.txtMesa.setText(pedido.getMesa());
 * this.txtPedidoMains1.setText(pedido.getPedidoMains1());
 * this.txtPedidoMains2.setText(pedido.getPedidoMains2());
 * this.txtPedidoMains2.setText(pedido.getPedidoMains3());
 * this.txtQuantidadeMains1.setText(pedido.getQuantidadeMains1());
 * this.txtQuantidadeMains2.setText(pedido.getQuantidadeMains2());
 * this.txtQuantidadeMains3.setText(pedido.getQuantidadeMains3());
 * this.txtPedidoDesserts1.setText(pedido.getPedidoDesserts1());
 * this.txtPedidoDesserts2.setText(pedido.getPedidoDesserts2());
 * this.txtPedidoDesserts3.setText(pedido.getPedidoDesserts3());
 * this.txtQuantidadeDesserts1.setText(pedido.getQuantidadeDesserts1());
 * this.txtQuantidadeDesserts2.setText(pedido.getQuantidadeDesserts2());
 * this.txtQuantidadeDesserts3.setText(pedido.getQuantidadeDesserts3());
 * this.txtPedidoDrinks1.setText(pedido.getPedidoDrinks1());
 * this.txtPedidoDrinks2.setText(pedido.getPedidoDrinks2());
 * this.txtPedidoDrinks3.setText(pedido.getPedidoDrinks3());
 * this.txtQuantidadeDrinks1.setText(pedido.getQuantidadeDrinks1());
 * this.txtQuantidadeDrinks2.setText(pedido.getQuantidadeDrinks2());
 * this.txtQuantidadeDrinks3.setText(pedido.getQuantidadeDrinks3());
 * 
 * 
 * 
 * 
 * }
 * 
 * @FXML public void handleButtonConfirmar() {
 * 
 * 
 * pedido.setMesa(txtMesa.getText());
 * pedido.setPedidoMains1(txtPedidoMains1.getText());
 * pedido.setPedidoMains2(txtPedidoMains2.getText());
 * pedido.setPedidoMains3(txtPedidoMains3.getText());
 * pedido.setQuantidadeMains1(txtQuantidadeMains1.getText());
 * pedido.setQuantidadeMains2(txtQuantidadeMains2.getText());
 * pedido.setQuantidadeMains3(txtQuantidadeMains3.getText());
 * pedido.setPedidoDesserts1(txtPedidoDesserts1.getText());
 * pedido.setPedidoDesserts2(txtPedidoDesserts2.getText());
 * pedido.setPedidoDesserts3(txtPedidoDesserts3.getText());
 * pedido.setQuantidadeDesserts1(txtQuantidadeDesserts1.getText());
 * pedido.setQuantidadeDesserts2(txtQuantidadeDesserts2.getText());
 * pedido.setQuantidadeDesserts3(txtQuantidadeDesserts3.getText());
 * pedido.setPedidoDrinks1(txtPedidoDrinks1.getText());
 * pedido.setPedidoDrinks2(txtPedidoDrinks2.getText());
 * pedido.setPedidoDrinks3(txtPedidoDrinks3.getText());
 * pedido.setQuantidadeDrinks1(txtQuantidadeDrinks1.getText());
 * pedido.setQuantidadeDrinks2(txtQuantidadeDrinks2.getText());
 * pedido.setQuantidadeDrinks3(txtQuantidadeDrinks3.getText());
 * 
 * 
 * 
 * 
 * buttonConfirmarClicked = true;
 * 
 * }
 * 
 * 
 * }
 */
