/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Sample Skeleton for 'Lista.fxml' Controller Class
 */

package br.com.maidcoffee.controller;

import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

import br.com.maidcoffee.dao.PedidoDAO;
import br.com.maidcoffee.model.Cadastro;
import br.com.maidcoffee.model.Pedido;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

/**
 * @author Daniel
 *
 */

public class ListaController {

	@FXML // ResourceBundle that was given to the FXMLLoader
	private ResourceBundle resources;

	@FXML // URL location of the FXML file that was given to the FXMLLoader
	private URL location;

	@FXML // fx:id="btnMaidListaDeletar"
	private Button btnMaidListaDeletar; // Value injected by FXMLLoader

	@FXML // fx:id="btnMaidListaPedido"
	private Button btnMaidListaPedido; // Value injected by FXMLLoader

	@FXML // fx:id="tTableViewPedido"
	private TableView<?> tTableViewPedido; // Value injected by FXMLLoader

	@FXML
	void handleSubmitButtonAction(ActionEvent event) {

		try {

			Parent root = FXMLLoader.load(getClass().getResource("../view/PedidoNew.fxml"));
			Stage stage = new Stage();
			Scene scene = new Scene(root);
			stage.setScene(scene);
			stage.show();

		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	@FXML // This method is called by the FXMLLoader when initialization is complete
	void initialize() {
		assert btnMaidListaDeletar != null : "fx:id=\"btnMaidListaDeletar\" was not injected: check your FXML file 'Lista.fxml'.";
		assert btnMaidListaPedido != null : "fx:id=\"btnMaidListaPedido\" was not injected: check your FXML file 'Lista.fxml'.";
		assert tTableViewPedido != null : "fx:id=\"tTableViewPedido\" was not injected: check your FXML file 'Lista.fxml'.";

	}
}

/*
 * public class ListaController {
 * 
 * @FXML // ResourceBundle that was given to the FXMLLoader private
 * ResourceBundle resources;
 * 
 * @FXML // URL location of the FXML file that was given to the FXMLLoader
 * private URL location;
 * 
 * @FXML // fx:id="btnMaidListaDeletar" private Button btnMaidListaDeletar; //
 * Value injected by FXMLLoader
 * 
 * @FXML // fx:id="btnMaidListaPedido" private Button btnMaidListaPedido; //
 * Value injected by FXMLLoader
 * 
 * @FXML // fx:id="tTableViewPedido" private TableView<Pedido> tTableViewPedido;
 * // Value injected by FXMLLoader
 * 
 * @FXML void handleSubmitButtonAction(ActionEvent event) {
 * 
 * try {
 * 
 * Parent root =
 * FXMLLoader.load(getClass().getResource("../view/PedidoNew.fxml")); Stage
 * stage = new Stage(); Scene scene = new Scene(root); stage.setScene(scene);
 * stage.show();
 * 
 * } catch (IOException e) { e.printStackTrace(); }
 * 
 * }
 * 
 * // private List<Pedido> listPedido; // private ObservableList<Pedido>
 * observableListPedido;
 * 
 * // private final Database database =
 * DatabaseFactory.getDatabase("maidcoffee"); // private final Connection
 * connection = database.conectar(); // private final PedidoDAO pedidoDAO = new
 * PedidoDAO();
 * 
 * @FXML // This method is called by the FXMLLoader when initialization is
 * complete void initialize() {
 * 
 * // pedidoDAO.setConnection(connection); // carregartTableViewPedido();
 * 
 * TableColumn<Pedido, String> colMesa = new TableColumn("Mesa");
 * colMesa.setCellValueFactory(data -> new
 * SimpleStringProperty(data.getValue().getMesa()));
 * 
 * TableColumn<Pedido, String> colPedidoMains1 = new
 * TableColumn("PedidoDesserts1"); colPedidoMains1.setCellValueFactory(data ->
 * new SimpleStringProperty(data.getValue().getPedidoDesserts1()));
 * 
 * TableColumn<Pedido, String> colPedidoMains2 = new
 * TableColumn("PedidoDesserts2"); colPedidoMains2.setCellValueFactory(data ->
 * new SimpleStringProperty(data.getValue().getPedidoDesserts2()));
 * 
 * TableColumn<Pedido, String> colPedidoMains3 = new
 * TableColumn("PedidoDesserts3"); colPedidoMains3.setCellValueFactory(data ->
 * new SimpleStringProperty(data.getValue().getPedidoDesserts3()));
 * 
 * TableColumn<Pedido, String> colQuantidadeMains1 = new
 * TableColumn("QuantidadeMains1"); colQuantidadeMains1
 * .setCellValueFactory(data -> new
 * SimpleStringProperty(data.getValue().getQuantidadeMains1()));
 * 
 * TableColumn<Pedido, String> colQuantidadeMains2 = new
 * TableColumn("QuantidadeMains2"); colQuantidadeMains2
 * .setCellValueFactory(data -> new
 * SimpleStringProperty(data.getValue().getQuantidadeMains2()));
 * 
 * TableColumn<Pedido, String> colQuantidadeMains3 = new
 * TableColumn("QuantidadeMains3"); colQuantidadeMains3
 * .setCellValueFactory(data -> new
 * SimpleStringProperty(data.getValue().getQuantidadeMains3()));
 * 
 * TableColumn<Pedido, String> colPedidoDesserts1 = new
 * TableColumn("PedidoDesserts1"); colPedidoDesserts1.setCellValueFactory(data
 * -> new SimpleStringProperty(data.getValue().getPedidoDesserts1()));
 * 
 * TableColumn<Pedido, String> colPedidoDesserts2 = new
 * TableColumn("PedidoDesserts2"); colPedidoDesserts2.setCellValueFactory(data
 * -> new SimpleStringProperty(data.getValue().getPedidoDesserts2()));
 * 
 * TableColumn<Pedido, String> colPedidoDesserts3 = new
 * TableColumn("PedidoDesserts3"); colPedidoDesserts3.setCellValueFactory(data
 * -> new SimpleStringProperty(data.getValue().getPedidoDesserts3()));
 * 
 * TableColumn<Pedido, String> colQuantidadeDesserts1 = new
 * TableColumn("QuantidadeDesserts1"); colQuantidadeDesserts1
 * .setCellValueFactory(data -> new
 * SimpleStringProperty(data.getValue().getQuantidadeDesserts1()));
 * 
 * TableColumn<Pedido, String> colQuantidadeDesserts2 = new
 * TableColumn("QuantidadeDesserts2"); colQuantidadeDesserts2
 * .setCellValueFactory(data -> new
 * SimpleStringProperty(data.getValue().getQuantidadeDesserts2()));
 * 
 * TableColumn<Pedido, String> colQuantidadeDesserts3 = new
 * TableColumn("QuantidadeDesserts3"); colQuantidadeDesserts3
 * .setCellValueFactory(data -> new
 * SimpleStringProperty(data.getValue().getQuantidadeDesserts3()));
 * 
 * TableColumn<Pedido, String> colPedidoDrinks1 = new
 * TableColumn("PedidoDrinks1"); colPedidoDrinks1.setCellValueFactory(data ->
 * new SimpleStringProperty(data.getValue().getPedidoDrinks1()));
 * 
 * TableColumn<Pedido, String> colPedidoDrinks2 = new
 * TableColumn("PedidoDrinks2"); colPedidoDrinks2.setCellValueFactory(data ->
 * new SimpleStringProperty(data.getValue().getPedidoDrinks2()));
 * 
 * TableColumn<Pedido, String> colPedidoDrinks3 = new
 * TableColumn("PedidoDrinks3"); colPedidoDrinks3.setCellValueFactory(data ->
 * new SimpleStringProperty(data.getValue().getPedidoDrinks3()));
 * 
 * TableColumn<Pedido, String> colQuantidadeDrinks1 = new
 * TableColumn("QuantidadeDrinks1"); colQuantidadeDrinks1
 * .setCellValueFactory(data -> new
 * SimpleStringProperty(data.getValue().getQuantidadeDrinks1()));
 * 
 * TableColumn<Pedido, String> colQuantidadeDrinks2 = new
 * TableColumn("QuantidadeDrinks2"); colQuantidadeDrinks2
 * .setCellValueFactory(data -> new
 * SimpleStringProperty(data.getValue().getQuantidadeDrinks2()));
 * 
 * TableColumn<Pedido, String> colQuantidadeDrinks3 = new
 * TableColumn("QuantidadeDrinks3"); colQuantidadeDrinks3
 * .setCellValueFactory(data -> new
 * SimpleStringProperty(data.getValue().getQuantidadeDrinks3())); /*
 * 
 * tTableViewPedido.getColumns().addAll(colMesa, colPedidoMains3,
 * colQuantidadeDrinks3);
 */
/*
 * assert btnMaidListaDeletar != null :
 * "fx:id=\"btnMaidListaDeletar\" was not injected: check your FXML file 'Lista.fxml'."
 * ; assert btnMaidListaPedido != null :
 * "fx:id=\"btnMaidListaPedido\" was not injected: check your FXML file 'Lista.fxml'."
 * ; assert tTableViewPedido != null :
 * "fx:id=\"tTableViewPedido\" was not injected: check your FXML file 'Lista.fxml'."
 * ;
 * 
 * }
 * 
 * /* public void carregartTableViewPedido() {
 * 
 * TableColumn<Pedido,String> colMesa = new TableColumn("Mesa");
 * colMesa.setCellValueFactory(data -> new
 * SimpleStringProperty(data.getValue().getMesa()));
 * 
 * TableColumn<Pedido,String> colPedidoMains1 = new
 * TableColumn("PedidoDesserts1"); colPedidoMains1.setCellValueFactory(data ->
 * new SimpleStringProperty(data.getValue().getPedidoDesserts1()));
 * 
 * 
 * TableColumn<Pedido,String> colPedidoMains2 = new
 * TableColumn("PedidoDesserts2"); colPedidoMains2.setCellValueFactory(data ->
 * new SimpleStringProperty(data.getValue().getPedidoDesserts2()));
 * 
 * TableColumn<Pedido,String> colPedidoMains3 = new
 * TableColumn("PedidoDesserts3"); colPedidoMains3.setCellValueFactory(data ->
 * new SimpleStringProperty(data.getValue().getPedidoDesserts3()));
 * 
 * 
 * 
 * TableColumn<Pedido,String> colQuantidadeMains1 = new
 * TableColumn("QuantidadeMains1"); colQuantidadeMains1.setCellValueFactory(data
 * -> new SimpleStringProperty(data.getValue().getQuantidadeMains1()));
 * 
 * 
 * TableColumn<Pedido,String> colQuantidadeMains2 = new
 * TableColumn("QuantidadeMains2"); colQuantidadeMains2.setCellValueFactory(data
 * -> new SimpleStringProperty(data.getValue().getQuantidadeMains2()));
 * 
 * TableColumn<Pedido,String> colQuantidadeMains3 = new
 * TableColumn("QuantidadeMains3"); colQuantidadeMains3.setCellValueFactory(data
 * -> new SimpleStringProperty(data.getValue().getQuantidadeMains3()));
 * 
 * 
 * 
 * TableColumn<Pedido,String> colPedidoDesserts1 = new
 * TableColumn("PedidoDesserts1"); colPedidoDesserts1.setCellValueFactory(data
 * -> new SimpleStringProperty(data.getValue().getPedidoDesserts1()));
 * 
 * TableColumn<Pedido,String> colPedidoDesserts2 = new
 * TableColumn("PedidoDesserts2"); colPedidoDesserts2.setCellValueFactory(data
 * -> new SimpleStringProperty(data.getValue().getPedidoDesserts2()));
 * 
 * TableColumn<Pedido,String> colPedidoDesserts3 = new
 * TableColumn("PedidoDesserts3"); colPedidoDesserts3.setCellValueFactory(data
 * -> new SimpleStringProperty(data.getValue().getPedidoDesserts3()));
 * 
 * 
 * 
 * 
 * 
 * TableColumn<Pedido,String> colQuantidadeDesserts1 = new
 * TableColumn("QuantidadeDesserts1");
 * colQuantidadeDesserts1.setCellValueFactory(data -> new
 * SimpleStringProperty(data.getValue().getQuantidadeDesserts1()));
 * 
 * TableColumn<Pedido,String> colQuantidadeDesserts2 = new
 * TableColumn("QuantidadeDesserts2");
 * colQuantidadeDesserts2.setCellValueFactory(data -> new
 * SimpleStringProperty(data.getValue().getQuantidadeDesserts2()));
 * 
 * TableColumn<Pedido,String> colQuantidadeDesserts3 = new
 * TableColumn("QuantidadeDesserts3");
 * colQuantidadeDesserts3.setCellValueFactory(data -> new
 * SimpleStringProperty(data.getValue().getQuantidadeDesserts3()));
 * 
 * 
 * 
 * 
 * 
 * 
 * TableColumn<Pedido,String> colPedidoDrinks1 = new
 * TableColumn("PedidoDrinks1"); colPedidoDrinks1.setCellValueFactory(data ->
 * new SimpleStringProperty(data.getValue().getPedidoDrinks1()));
 * 
 * TableColumn<Pedido,String> colPedidoDrinks2 = new
 * TableColumn("PedidoDrinks2"); colPedidoDrinks2.setCellValueFactory(data ->
 * new SimpleStringProperty(data.getValue().getPedidoDrinks2()));
 * 
 * TableColumn<Pedido,String> colPedidoDrinks3 = new
 * TableColumn("PedidoDrinks3"); colPedidoDrinks3.setCellValueFactory(data ->
 * new SimpleStringProperty(data.getValue().getPedidoDrinks3()));
 * 
 * 
 * 
 * 
 * 
 * 
 * TableColumn<Pedido,String> colQuantidadeDrinks1 = new
 * TableColumn("QuantidadeDrinks1");
 * colQuantidadeDrinks1.setCellValueFactory(data -> new
 * SimpleStringProperty(data.getValue().getQuantidadeDrinks1()));
 * 
 * TableColumn<Pedido,String> colQuantidadeDrinks2 = new
 * TableColumn("QuantidadeDrinks2");
 * colQuantidadeDrinks2.setCellValueFactory(data -> new
 * SimpleStringProperty(data.getValue().getQuantidadeDrinks2()));
 * 
 * TableColumn<Pedido,String> colQuantidadeDrinks3 = new
 * TableColumn("QuantidadeDrinks3");
 * colQuantidadeDrinks3.setCellValueFactory(data -> new
 * SimpleStringProperty(data.getValue().getQuantidadeDrinks3()));
 * 
 * 
 * tTableViewPedido.getColumns().addAll(colMesa, colPedidoMains1,
 * colPedidoMains2, colPedidoMains3, colQuantidadeMains1, colQuantidadeMains2,
 * colQuantidadeMains3, colPedidoDesserts1, colPedidoDesserts2,
 * colPedidoDesserts3, colQuantidadeDesserts1, colQuantidadeDesserts2,
 * colQuantidadeDesserts3, colPedidoDrinks1, colPedidoDrinks2, colPedidoDrinks3,
 * colQuantidadeDrinks1, colQuantidadeDrinks2, colQuantidadeDrinks3);
 * 
 * colMesa.setCellValueFactory(new PropertyValueFactory<>("Mesa"));
 * colPedidoMains1.setCellValueFactory(new
 * PropertyValueFactory<>("PedidoMains1"));
 * colPedidoMains2.setCellValueFactory(new
 * PropertyValueFactory<>("PedidoMains2"));
 * colPedidoMains3.setCellValueFactory(new
 * PropertyValueFactory<>("PedidoMains3"));
 * colQuantidadeMains1.setCellValueFactory(new
 * PropertyValueFactory<>("colQuantidadeMains1"));
 * colQuantidadeMains2.setCellValueFactory(new
 * PropertyValueFactory<>("colQuantidadeMains2"));
 * colQuantidadeMains3.setCellValueFactory(new
 * PropertyValueFactory<>("colQuantidadeMains3"));
 * colPedidoDesserts1.setCellValueFactory(new
 * PropertyValueFactory<>("PedidoDesserts1"));
 * colPedidoDesserts2.setCellValueFactory(new
 * PropertyValueFactory<>("PedidoDesserts2"));
 * colPedidoDesserts3.setCellValueFactory(new
 * PropertyValueFactory<>("PedidoDesserts3"));
 * 
 * colQuantidadeDesserts1.setCellValueFactory(new
 * PropertyValueFactory<>("colQuantidadeDesserts1"));
 * colQuantidadeDesserts2.setCellValueFactory(new
 * PropertyValueFactory<>("colQuantidadeDesserts2"));
 * colQuantidadeDesserts3.setCellValueFactory(new
 * PropertyValueFactory<>("colQuantidadeDesserts3"));
 * 
 * colPedidoDrinks1.setCellValueFactory(new
 * PropertyValueFactory<>("PedidoDrinks1"));
 * colPedidoDrinks2.setCellValueFactory(new
 * PropertyValueFactory<>("PedidoDrinks2"));
 * colPedidoDrinks3.setCellValueFactory(new
 * PropertyValueFactory<>("PedidoDrinks3"));
 * 
 * colQuantidadeDrinks1.setCellValueFactory(new
 * PropertyValueFactory<>("colQuantidadeDrinks1"));
 * colQuantidadeDrinks2.setCellValueFactory(new
 * PropertyValueFactory<>("colQuantidadeDrinks2"));
 * colQuantidadeDrinks3.setCellValueFactory(new
 * PropertyValueFactory<>("colQuantidadeDrinks3"));
 * 
 * 
 * 
 * 
 * listPedido = pedidoDAO.listar();
 * 
 * observableListPedido = FXCollections.observableArrayList(listPedido);
 * tTableViewPedido.setItems(observableListPedido); }
 * 
 * 
 * 
 * @FXML public void handleButtonRemover() throws IOException { Pedido pedido =
 * tTableViewPedido.getSelectionModel().getSelectedItem(); if (pedido != null) {
 * pedidoDAO.remover(pedido); carregartTableViewPedido(); } else { Alert alert =
 * new Alert(Alert.AlertType.ERROR);
 * alert.setContentText("Por favor, escolha um cliente na Tabela!");
 * alert.show(); } }
 * 
 * 
 * 
 * 
 * }
 */
