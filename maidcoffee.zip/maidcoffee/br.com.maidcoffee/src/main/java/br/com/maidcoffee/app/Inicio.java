/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package br.com.maidcoffee.app;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/*
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.hibernate.cfg.Settings;*/
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 * @author Beto
 *
 */

public class Inicio extends Application {

	@Override
	public void start(Stage primaryStage) throws Exception {

		try {

			Parent root = FXMLLoader.load(getClass().getResource("../view/Login.fxml"));
			// Parent root = FXMLLoader.load(getClass().getResource("../view/Cadastro.fxml"));
			
			//Parent root = FXMLLoader.load(getClass().getResource("../view/Maid.fxml"));
			/// Parent root = FXMLLoader.load(getClass().getResource("../view/Lista.fxml"));
			/// Parent root = FXMLLoader.load(getClass().getResource("../view/PedidoNew.fxml"));
			
			
			Scene sena = new Scene(root);
			primaryStage.setScene(sena);
			primaryStage.show();

			primaryStage.setTitle("Maid Coffee");

		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	

	static final Logger logger = LogManager.getLogger(Inicio.class.getName());

	public static void main(String[] args) {

		System.out.println("Carregando... ");

		launch(args);
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("maidcoffee");
		EntityManager em = emf.createEntityManager();

	}

}
