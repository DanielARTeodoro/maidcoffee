/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.maidcoffee.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/// import br.com.nerdgeek.app.Inicio;
import br.com.maidcoffee.model.Cadastro;

/**
 * @author Daniel
 *
 */

public class CadastroDAO {

	
	static final Logger logger = LogManager.getLogger(CadastroDAO.class.getName());
	final EntityManagerFactory emf = Persistence.createEntityManagerFactory("maidcoffee");
	protected EntityManager em = null;

	public CadastroDAO() {
		super();
		if (em == null) {
			em = emf.createEntityManager();
		}

	}
	
	
	
	public Cadastro getById(final int id) {
		return em.find(Cadastro.class, id);
	}
	
	public List<Cadastro> getAll() {
		em.getTransaction().begin();
		@SuppressWarnings("unchecked")
		List<Cadastro> cadastros = em.createQuery("FROM " + Cadastro.class.getName()).getResultList();
		return cadastros;
	}
	

	public void inserir(Cadastro c) {
		logger.info("Adicionando Cadastro ao BD");
		try {
			em.getTransaction().begin();
			em.persist(c);
			em.getTransaction().commit();
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("Erro ao inserir Cadastro" + e.getMessage());
			em.getTransaction().rollback();
		} finally {
			em.clear();
			em.close();
		}

	}

	public void remover(Cadastro c) {

		logger.info("Removeido o Cadastro do BD");
		try {
			em.getTransaction().begin();
			em.remove(c);
			em.getTransaction().commit();
		} catch (Exception e) {
			// TODO:handle exception logger.error("Erro ao remover o Cadastro" +
			// e.getMessage());
			em.getTransaction().rollback();
		} finally {
			em.clear();
			em.close();

		}

	}

	public void alterar(Cadastro c) {

		logger.info("alterado o Cadastro do BD");
		try {
			em.getTransaction().begin();
			em.merge(c);
			em.getTransaction().commit();
		} catch (Exception e) {
			// TODO:handle exception logger.error("Erro ao alterar o Cadastro" +
			// e.getMessage());
			em.getTransaction().rollback();
		} finally {
			em.clear();
			em.close();

		}

	}

	public boolean getMaid(String maid, String senha) {
		boolean recinhesimentoDeMaid = false;
		String sql = "FROM Cadastro cad WHERE cad.maid = :maid and cad.senha = :senha";
		Query sqlMaid = em.createQuery(sql);
		sqlMaid.setParameter("maid", maid);
		sqlMaid.setParameter("senha", senha);

		@SuppressWarnings("unchecked")
		List<Cadastro> loginMaid = sqlMaid.getResultList();

		if (loginMaid.size() > 0) {
			return true;
		}
		return recinhesimentoDeMaid;
	}

	/*
	public List<Cadastro> consultarTodos() {

	 return em.createQuery("FROM " + Cadastro.class.getName()).getResultList();
	}*/

	/*
	 * public void consultarNome() {}
	 */

}
