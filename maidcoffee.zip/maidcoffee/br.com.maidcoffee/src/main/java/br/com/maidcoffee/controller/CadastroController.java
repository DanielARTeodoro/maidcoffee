/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Sample Skeleton for 'Cadastro.fxml' Controller Class
 */

package br.com.maidcoffee.controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import br.com.maidcoffee.dao.CadastroDAO;
import br.com.maidcoffee.jpa.Conexao;
import br.com.maidcoffee.model.Cadastro;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * @author Daniel
 *
 */

public class CadastroController {

	@FXML // ResourceBundle that was given to the FXMLLoader
	private ResourceBundle resources;

	@FXML // URL location of the FXML file that was given to the FXMLLoader
	private URL location;

	@FXML // fx:id="txtNome"
	private TextField txtNome; // Value injected by FXMLLoader

	@FXML // fx:id="txtCpf"
	private TextField txtCpf; // Value injected by FXMLLoader

	@FXML // fx:id="btnLogar"
	private Button btnLogar; // Value injected by FXMLLoader

	@FXML // fx:id="btnCadastrar"
	private Button btnCadastrar; // Value injected by FXMLLoader

	@FXML // fx:id="btnMaidCoffee"
	private Button btnMaidCoffee; // Value injected by FXMLLoader

	@FXML // fx:id="txtNomeMaid"
	private TextField txtNomeMaid; // Value injected by FXMLLoader

	@FXML // fx:id="txtEmail"
	private TextField txtEmail; // Value injected by FXMLLoader

	@FXML // fx:id="txtSenha"
	private TextField txtSenha; // Value injected by FXMLLoader

	@FXML
	void handleSubmitButtonAction(ActionEvent event) {

		

		try {

			Parent root = FXMLLoader.load(getClass().getResource("../view/Login.fxml"));
			Stage stage = new Stage();
			Scene scene = new Scene(root);
			stage.setScene(scene);
			stage.show();

		} catch (IOException e) {
			e.printStackTrace();
		}

	}

	@FXML
	void handleSubmitButtonAction0(ActionEvent event) {

		try {

			Parent root = FXMLLoader.load(getClass().getResource("../view/Maid.fxml"));
			Stage stage = new Stage();
			Scene scene = new Scene(root);
			stage.setScene(scene);
			stage.show();

		} catch (IOException e) {
			e.printStackTrace();
		}

	}
	/*
	 * //Atributos para manipula��o de Banco de Dados private final Database
	 * database = DatabaseFactory.getDatabase("postgresql"); private final
	 * Connection connection = database.conectar(); private final ClienteDAO
	 * clienteDAO = new ClienteDAO();
	 */

	Conexao conexao = new Conexao();
	private final CadastroDAO cadastroDAO = new CadastroDAO();

	@FXML // This method is called by the FXMLLoader when initialization is complete
	void initialize() {
		
		
		
		assert txtNome != null : "fx:id=\"txtNome\" was not injected: check your FXML file 'Cadastro.fxml'.";
		assert txtCpf != null : "fx:id=\"txtCpf\" was not injected: check your FXML file 'Cadastro.fxml'.";
		assert btnLogar != null : "fx:id=\"btnLogar\" was not injected: check your FXML file 'Cadastro.fxml'.";
		assert btnCadastrar != null : "fx:id=\"btnCadastrar\" was not injected: check your FXML file 'Cadastro.fxml'.";
		assert btnMaidCoffee != null : "fx:id=\"btnMaidCoffee\" was not injected: check your FXML file 'Cadastro.fxml'.";
		assert txtNomeMaid != null : "fx:id=\"txtNomeMaid\" was not injected: check your FXML file 'Cadastro.fxml'.";
		assert txtEmail != null : "fx:id=\"txtEmail\" was not injected: check your FXML file 'Cadastro.fxml'.";
		assert txtSenha != null : "fx:id=\"txtSenha\" was not injected: check your FXML file 'Cadastro.fxml'.";

	}

	/*
	 * private Stage dialogStage; private boolean buttonConfirmarClicked = false;
	 * private Cadastro cadastro;
	 * 
	 * /**
	 * 
	 * @return the dialogStage
	 * 
	 * public Stage getDialogStage() { return dialogStage; }
	 * 
	 * 
	 * /**
	 * 
	 * @param dialogStage the dialogStage to set
	 * 
	 * public void setDialogStage(Stage dialogStage) { this.dialogStage =
	 * dialogStage; }
	 * 
	 * 
	 * /**
	 * 
	 * @return the buttonConfirmarClicked
	 * 
	 * public boolean isButtonConfirmarClicked() { return buttonConfirmarClicked; }
	 * 
	 * 
	 * /**
	 * 
	 * @param buttonConfirmarClicked the buttonConfirmarClicked to set
	 * 
	 * public void setButtonConfirmarClicked(boolean buttonConfirmarClicked) {
	 * this.buttonConfirmarClicked = buttonConfirmarClicked; }
	 * 
	 * 
	 * /**
	 * 
	 * @return the cadastro
	 * 
	 * public Cadastro getCadastro() { return cadastro; }
	 * 
	 * 
	 * /**
	 * 
	 * @param cadastro the cadastro to set
	 * 
	 * public void setCadastro(Cadastro cadastro) { this.cadastro = cadastro;
	 * this.txtNome.setText(cadastro.getNome());
	 * this.txtCpf.setText(cadastro.getCpf());
	 * this.txtNomeMaid.setText(cadastro.getNomeMaid());
	 * this.txtEmail.setText(cadastro.getEmail());
	 * this.txtSenha.setText(cadastro.getSenha());
	 * 
	 * }
	 * 
	 * @FXML public void handleButtonConfirmar() {
	 * 
	 * if (validarEntradaDeDados()) {
	 * 
	 * cadastro.setNome(txtNome.getText()); cadastro.setCpf(txtCpf.getText());
	 * cadastro.setNomeMaid(txtNomeMaid.getText());
	 * cadastro.setEmail(txtEmail.getText()); cadastro.setSenha(txtSenha.getText());
	 * 
	 * 
	 * buttonConfirmarClicked = true;
	 * 
	 * }
	 * 
	 * 
	 * 
	 * }
	 * 
	 * 
	 * 
	 * 
	 * private boolean validarEntradaDeDados() { String errorMessage = "";
	 * 
	 * if (txtNome.getText() == null || txtNome.getText().length() == 0) {
	 * errorMessage += "Nome inv�lido!\n"; } if (txtCpf.getText() == null ||
	 * txtCpf.getText().length() == 0) { errorMessage += "CPF inv�lido!\n"; } if
	 * (txtNomeMaid.getText() == null || txtNomeMaid.getText().length() == 0) {
	 * errorMessage += "Nome Maid inv�lido!\n"; }
	 * 
	 * if (txtEmail.getText() == null || txtEmail.getText().length() == 0) {
	 * errorMessage += "Email inv�lido!\n"; } if (txtSenha.getText() == null ||
	 * txtSenha.getText().length() == 0) { errorMessage += "Senha inv�lido!\n"; }
	 * 
	 * 
	 * 
	 * if (errorMessage.length() == 0) { return true; } else {
	 * 
	 * Alert alert = new Alert(Alert.AlertType.ERROR);
	 * alert.setTitle("Erro no cadastro");
	 * alert.setHeaderText("Campos inv�lidos, por favor, corrija...");
	 * alert.setContentText(errorMessage); alert.show(); return false; }
	 * 
	 * }
	 */

	private Stage dialogStage;
	private boolean buttonConfirmarClicked = false;
	private Cadastro cadastro;

	/**
	 * @return the dialogStage
	 */
	public Stage getDialogStage() {
		return dialogStage;
	}

	/**
	 * @param dialogStage the dialogStage to set
	 */
	public void setDialogStage(Stage dialogStage) {
		this.dialogStage = dialogStage;
	}

	/**
	 * @return the buttonConfirmarClicked
	 */
	public boolean isButtonConfirmarClicked() {
		return buttonConfirmarClicked;
	}

	/**
	 * @param buttonConfirmarClicked the buttonConfirmarClicked to set
	 */
	public void setButtonConfirmarClicked(boolean buttonConfirmarClicked) {
		this.buttonConfirmarClicked = buttonConfirmarClicked;
	}

	/**
	 * @return the cadastro
	 */
	public Cadastro getCadastro() {
		return cadastro;
	}

	/**
	 * @param cadastro the cadastro to set
	 */
	public void setCadastro(Cadastro cadastro) {
		this.cadastro = cadastro;
		this.txtNome.setText(cadastro.getNome());
		this.txtCpf.setText(cadastro.getCpf());
		this.txtNomeMaid.setText(cadastro.getNomeMaid());
		this.txtEmail.setText(cadastro.getEmail());
		this.txtSenha.setText(cadastro.getSenha());

	}

	@FXML
	public void handleButtonConfirmar() {

		if (validarEntradaDeDados()) {

			cadastro.setNome(txtNome.getText());
			cadastro.setCpf(txtCpf.getText());
			cadastro.setNomeMaid(txtNomeMaid.getText());
			cadastro.setEmail(txtEmail.getText());
			cadastro.setSenha(txtSenha.getText());

			buttonConfirmarClicked = true;
			dialogStage.close();
		}

	}

	// Validar entrada de dados para o cadastro
	private boolean validarEntradaDeDados() {
		String errorMessage = "";

		if (txtNome.getText() == null || txtNome.getText().length() == 0) {
			errorMessage += "Nome inv�lido!\n";
		}
		if (txtCpf.getText() == null || txtCpf.getText().length() == 0) {
			errorMessage += "CPF inv�lido!\n";
		}
		if (txtNomeMaid.getText() == null || txtNomeMaid.getText().length() == 0) {
			errorMessage += "Nome Maid inv�lido!\n";
		}

		if (txtEmail.getText() == null || txtEmail.getText().length() == 0) {
			errorMessage += "Email inv�lido!\n";
		}
		if (txtSenha.getText() == null || txtSenha.getText().length() == 0) {
			errorMessage += "Senha inv�lido!\n";
		}

		if (errorMessage.length() == 0) {
			return true;
		} else {

			Alert alert = new Alert(Alert.AlertType.ERROR);
			alert.setTitle("Erro no cadastro");
			alert.setHeaderText("Campos inv�lidos, por favor, corrija...");
			alert.setContentText(errorMessage);
			alert.show();
			return false;
		}

	}
}
