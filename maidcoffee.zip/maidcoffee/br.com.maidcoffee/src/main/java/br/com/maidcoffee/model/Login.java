/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.maidcoffee.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import javafx.stage.Stage;

@Entity
@Table(name = "tb_login")

/**
 *
 * @author Adler
 */
public class Login {

	@Id
	@GeneratedValue
	@Column(name = "idLogin")

	private Integer id;

	/// private Cadastro cadastro;
	@Column
	private String maid;
	@Column
	private String senha;

	/**
	 * 
	 */
	public Login() {

	}

	/**
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}

	/**
	 * @return the maid
	 */
	public String getMaid() {
		return maid;
	}

	/**
	 * @param maid the maid to set
	 */
	public void setMaid(String maid) {
		this.maid = maid;
	}

	/**
	 * @return the senha
	 */
	public String getSenha() {
		return senha;
	}

	/**
	 * @param senha the senha to set
	 */
	public void setSenha(String senha) {
		this.senha = senha;
	}

	/*
	 * public static Stage getStage() { // TODO Auto-generated method stub return
	 * null; }
	 */
}
