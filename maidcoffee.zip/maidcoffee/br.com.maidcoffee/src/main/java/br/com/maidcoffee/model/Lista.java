/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.maidcoffee.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "tb_lista")

/**
 *
 * @author Daniel
 */
public class Lista {

	@Id
	@GeneratedValue
	@Column(name = "idLista")

	private Integer id;

	/// Mesa
	@Column
	private String maidMesa;

	/// MAINS
	@Column
	private String maidQuantidadeMains1;
	@Column
	private String maidQuantidadeMains2;
	@Column
	private String maidQuantidadeMains3;

	@Column
	private String maidPedidoMains1;
	@Column
	private String maidPedidoMains2;
	@Column
	private String maidPedidoMains3;

	/// DESSERTS

	@Column
	private String maidQuantidadeDesserts1;
	@Column
	private String maidQuantidadeDesserts2;
	@Column
	private String maidQuantidadeDesserts3;

	@Column
	private String maidPedidoDesserts1;
	@Column
	private String maidPedidoDesserts2;
	@Column
	private String maidPedidoDesserts3;

	/// DRINKS

	@Column
	private String maidQuantidadeDrinks1;
	@Column
	private String maidQuantidadeDrinks2;
	@Column
	private String maidQuantidadeDrinks3;

	@Column
	private String maidPedidoDrinks1;
	@Column
	private String maidPedidoDrinks2;
	@Column
	private String maidPedidoDrinks3;

	/**
	 * 
	 */
	public Lista() {

	}

	/**
	 * @return the id
	 */
	public Integer getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(Integer id) {
		this.id = id;
	}

	/**
	 * @return the maidMesa
	 */
	public String getMaidMesa() {
		return maidMesa;
	}

	/**
	 * @param maidMesa the maidMesa to set
	 */
	public void setMaidMesa(String maidMesa) {
		this.maidMesa = maidMesa;
	}

	/**
	 * @return the maidQuantidadeMains1
	 */
	public String getMaidQuantidadeMains1() {
		return maidQuantidadeMains1;
	}

	/**
	 * @param maidQuantidadeMains1 the maidQuantidadeMains1 to set
	 */
	public void setMaidQuantidadeMains1(String maidQuantidadeMains1) {
		this.maidQuantidadeMains1 = maidQuantidadeMains1;
	}

	/**
	 * @return the maidQuantidadeMains2
	 */
	public String getMaidQuantidadeMains2() {
		return maidQuantidadeMains2;
	}

	/**
	 * @param maidQuantidadeMains2 the maidQuantidadeMains2 to set
	 */
	public void setMaidQuantidadeMains2(String maidQuantidadeMains2) {
		this.maidQuantidadeMains2 = maidQuantidadeMains2;
	}

	/**
	 * @return the maidQuantidadeMains3
	 */
	public String getMaidQuantidadeMains3() {
		return maidQuantidadeMains3;
	}

	/**
	 * @param maidQuantidadeMains3 the maidQuantidadeMains3 to set
	 */
	public void setMaidQuantidadeMains3(String maidQuantidadeMains3) {
		this.maidQuantidadeMains3 = maidQuantidadeMains3;
	}

	/**
	 * @return the maidPedidoMains1
	 */
	public String getMaidPedidoMains1() {
		return maidPedidoMains1;
	}

	/**
	 * @param maidPedidoMains1 the maidPedidoMains1 to set
	 */
	public void setMaidPedidoMains1(String maidPedidoMains1) {
		this.maidPedidoMains1 = maidPedidoMains1;
	}

	/**
	 * @return the maidPedidoMains2
	 */
	public String getMaidPedidoMains2() {
		return maidPedidoMains2;
	}

	/**
	 * @param maidPedidoMains2 the maidPedidoMains2 to set
	 */
	public void setMaidPedidoMains2(String maidPedidoMains2) {
		this.maidPedidoMains2 = maidPedidoMains2;
	}

	/**
	 * @return the maidPedidoMains3
	 */
	public String getMaidPedidoMains3() {
		return maidPedidoMains3;
	}

	/**
	 * @param maidPedidoMains3 the maidPedidoMains3 to set
	 */
	public void setMaidPedidoMains3(String maidPedidoMains3) {
		this.maidPedidoMains3 = maidPedidoMains3;
	}

	/**
	 * @return the maidQuantidadeDesserts1
	 */
	public String getMaidQuantidadeDesserts1() {
		return maidQuantidadeDesserts1;
	}

	/**
	 * @param maidQuantidadeDesserts1 the maidQuantidadeDesserts1 to set
	 */
	public void setMaidQuantidadeDesserts1(String maidQuantidadeDesserts1) {
		this.maidQuantidadeDesserts1 = maidQuantidadeDesserts1;
	}

	/**
	 * @return the maidQuantidadeDesserts2
	 */
	public String getMaidQuantidadeDesserts2() {
		return maidQuantidadeDesserts2;
	}

	/**
	 * @param maidQuantidadeDesserts2 the maidQuantidadeDesserts2 to set
	 */
	public void setMaidQuantidadeDesserts2(String maidQuantidadeDesserts2) {
		this.maidQuantidadeDesserts2 = maidQuantidadeDesserts2;
	}

	/**
	 * @return the maidQuantidadeDesserts3
	 */
	public String getMaidQuantidadeDesserts3() {
		return maidQuantidadeDesserts3;
	}

	/**
	 * @param maidQuantidadeDesserts3 the maidQuantidadeDesserts3 to set
	 */
	public void setMaidQuantidadeDesserts3(String maidQuantidadeDesserts3) {
		this.maidQuantidadeDesserts3 = maidQuantidadeDesserts3;
	}

	/**
	 * @return the maidPedidoDesserts1
	 */
	public String getMaidPedidoDesserts1() {
		return maidPedidoDesserts1;
	}

	/**
	 * @param maidPedidoDesserts1 the maidPedidoDesserts1 to set
	 */
	public void setMaidPedidoDesserts1(String maidPedidoDesserts1) {
		this.maidPedidoDesserts1 = maidPedidoDesserts1;
	}

	/**
	 * @return the maidPedidoDesserts2
	 */
	public String getMaidPedidoDesserts2() {
		return maidPedidoDesserts2;
	}

	/**
	 * @param maidPedidoDesserts2 the maidPedidoDesserts2 to set
	 */
	public void setMaidPedidoDesserts2(String maidPedidoDesserts2) {
		this.maidPedidoDesserts2 = maidPedidoDesserts2;
	}

	/**
	 * @return the maidPedidoDesserts3
	 */
	public String getMaidPedidoDesserts3() {
		return maidPedidoDesserts3;
	}

	/**
	 * @param maidPedidoDesserts3 the maidPedidoDesserts3 to set
	 */
	public void setMaidPedidoDesserts3(String maidPedidoDesserts3) {
		this.maidPedidoDesserts3 = maidPedidoDesserts3;
	}

	/**
	 * @return the maidQuantidadeDrinks1
	 */
	public String getMaidQuantidadeDrinks1() {
		return maidQuantidadeDrinks1;
	}

	/**
	 * @param maidQuantidadeDrinks1 the maidQuantidadeDrinks1 to set
	 */
	public void setMaidQuantidadeDrinks1(String maidQuantidadeDrinks1) {
		this.maidQuantidadeDrinks1 = maidQuantidadeDrinks1;
	}

	/**
	 * @return the maidQuantidadeDrinks2
	 */
	public String getMaidQuantidadeDrinks2() {
		return maidQuantidadeDrinks2;
	}

	/**
	 * @param maidQuantidadeDrinks2 the maidQuantidadeDrinks2 to set
	 */
	public void setMaidQuantidadeDrinks2(String maidQuantidadeDrinks2) {
		this.maidQuantidadeDrinks2 = maidQuantidadeDrinks2;
	}

	/**
	 * @return the maidQuantidadeDrinks3
	 */
	public String getMaidQuantidadeDrinks3() {
		return maidQuantidadeDrinks3;
	}

	/**
	 * @param maidQuantidadeDrinks3 the maidQuantidadeDrinks3 to set
	 */
	public void setMaidQuantidadeDrinks3(String maidQuantidadeDrinks3) {
		this.maidQuantidadeDrinks3 = maidQuantidadeDrinks3;
	}

	/**
	 * @return the maidPedidoDrinks1
	 */
	public String getMaidPedidoDrinks1() {
		return maidPedidoDrinks1;
	}

	/**
	 * @param maidPedidoDrinks1 the maidPedidoDrinks1 to set
	 */
	public void setMaidPedidoDrinks1(String maidPedidoDrinks1) {
		this.maidPedidoDrinks1 = maidPedidoDrinks1;
	}

	/**
	 * @return the maidPedidoDrinks2
	 */
	public String getMaidPedidoDrinks2() {
		return maidPedidoDrinks2;
	}

	/**
	 * @param maidPedidoDrinks2 the maidPedidoDrinks2 to set
	 */
	public void setMaidPedidoDrinks2(String maidPedidoDrinks2) {
		this.maidPedidoDrinks2 = maidPedidoDrinks2;
	}

	/**
	 * @return the maidPedidoDrinks3
	 */
	public String getMaidPedidoDrinks3() {
		return maidPedidoDrinks3;
	}

	/**
	 * @param maidPedidoDrinks3 the maidPedidoDrinks3 to set
	 */
	public void setMaidPedidoDrinks3(String maidPedidoDrinks3) {
		this.maidPedidoDrinks3 = maidPedidoDrinks3;
	}

}
